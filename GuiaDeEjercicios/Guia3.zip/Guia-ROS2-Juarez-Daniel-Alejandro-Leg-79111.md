<!-- Guia de ROS2 escrita en Markdown 
     Alumno: Juarez Daniel Alejandro 
     Legajo: 79111
     Año: 2024
-->
# <span style="color: red;"> Ejercicios de línea de comando de ROS 2 </span>

## <span style="color: blue;"> Realizar las siguientes actividades teniendo en ejecución el simulador Gazebo con el modelo del robot TurtleBot3. </span>

 
### <span style="color: green;"> 1. Utilizar el comando de ROS para listar los nodos en ejecución, ¿cuáles son? </span>

```python
user:~$ ros2 node list
/gazebo
/rgb_camera_controller
/robot_state_publisher
/turtlebot3_diff_drive
/turtlebot3_imu
/turtlebot3_joint_state
/turtlebot3_laserscan
```
### <span style="color: green;"> 2. Utilizar el comando de ROS para listar los tópicos disponibles, ¿cuáles son? </span>

```python
user:~$ ros2 topic list
/clock
/cmd_vel
/imu
/joint_states
/odom
/parameter_events
/performance_metrics
```
### <span style="color: green;"> 3. ¿Qué tipo de mensaje lleva el tópico odom? </span>

```python
user:~$ ros2 topic info /odom
Type: nav_msgs/msg/Odometry
Publisher count: 2
Subscription count: 0
```
### <span style="color: green;"> 4. ¿Cuáles son los campos que componen el mensaje del tópico odom? </span>

```python
user:~$ ros2 interface show nav_msgs/msg/Odometry
# This represents an estimate of a position and velocity in free space.
# The pose in this message should be specified in the coordinate frame given by header.frame_id
# The twist in this message should be specified in the coordinate frame given by the child_frame_id

# Includes the frame id of the pose parent.
std_msgs/Header header
builtin_interfaces/Time stamp
int32 sec
uint32 nanosec
string frame_id

# Frame id the pose points to. The twist is in this coordinate frame.
string child_frame_id

# Estimated pose that is typically relative to a fixed world frame.
geometry_msgs/PoseWithCovariance pose
Pose pose
Point position
float64 x
float64 y
float64 z

Quaternion orientation
float64 x 0
float64 y 0
float64 z 0
float64 w 1
float64[36] covariance

# Estimated linear and angular velocity relative to child_frame_id.
geometry_msgs/TwistWithCovariance twist
Twist twist
Vector3 linear
float64 x
float64 y
float64 z
Vector3 angular
float64 x
float64 y
float64 z
float64[36] covariance
```
### <span style="color: green;"> 5. Ejecutar el comando de ROS que permite ver los mensajes publicados en el tópico odom. </span>

```python
user:~$ ros2 topic echo /odom
header:
stamp:
sec: 2124
nanosec: 626000000
frame_id: odom
child_frame_id: base_footprint
pose:
pose:
position:
x: 1.9102626287694262
y: -0.8271033837398263
z: 0.01164000409419725

orientation:
x: -0.0003940652520738766
y: 0.18705134564325354
z: 0.001603322364950513
w: 0.9823487507820322

covariance:
-  1.0e-05
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  1.0e-05
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  1000000000000.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  1000000000000.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  1000000000000.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.001

twist:
twist:
linear:
x: 0.0081495433320924
y: 0.0002920680859967263
z: 0.0

angular:
x: 0.0
y: 0.0
z: 0.0019827179029267197

covariance:
-  1.0e-05
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  1.0e-05
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  1000000000000.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  1000000000000.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  1000000000000.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.001
---
```
### <span style="color: green;"> 6. Ejecutar el comando de ROS para solo la pose (posición y orientación) del robot dada en el tópico odom. </span>

```python
user:~$ ros2 topic echo /odom | grep -A 11 "pose:"
pose:
pose:
position:
x: 1.9101859391286422
y: -0.8251480501394258
z: 0.011663693913046235

orientation:
x: -0.000141001280453696
y: 0.1877379214223938
z: 0.0011683290223632962
w: 0.9822184522731863

covariance:
- 1.0e-05
--
```
### <span style="color: green;"> 7. Ejecutar el comando de ROS que permite determinar la frecuencia a la que se publican los mensajes del tópico odom. </span>

```python
user:~$ ros2 topic hz /odom
average rate: 28.811
min: 0.026s  max: 0.049s std dev: 0.00588s window: 30
average rate: 28.026
min: 0.026s  max: 0.049s std dev: 0.00521s window: 58
average rate: 28.013
min: 0.026s  max: 0.049s std dev: 0.00539s window: 87
average rate: 27.932
min: 0.026s  max: 0.052s std dev: 0.00569s window: 115
average rate: 27.874
min: 0.026s  max: 0.054s std dev: 0.00568s window: 143
average rate: 27.896
min: 0.026s  max: 0.054s std dev: 0.00556s window: 172
```
### <span style="color: green;"> 8. Ejecutar el comando que permita ver el campo position del tópico odom (posición x, y y z). </span>

```python
user:~$ ros2 topic echo /odom | grep -A 6  "position:"

position:
x: 2.0352497224541723
y: -0.6873889094788885
z: 0.008468981049837444

orientation:
x: -0.005225060151664313
y: -0.00030488540249936643
--
```
### <span style="color: green;"> 9. ¿Qué tipo de mensaje lleva el tópico scan? </span>

```python
user:~$ ros2 topic info /scan
Type: sensor_msgs/msg/LaserScan
Publisher count: 1
Subscription count: 0
```
### <span style="color: green;"> 10. ¿Cuáles son los campos que componen el mensaje del tópico scan? </span>

```python

user:~$ ros2 interface show sensor_msgs/msg/LaserScan
# Single scan from a planar laser range-finder
#
# If you have another ranging device with different behavior (e.g. a sonar
# array), please find or create a different message, since applications
# will make fairly laser-specific assumptions about this data

std_msgs/Header header # timestamp in the header is the acquisition time of
builtin_interfaces/Time stamp
int32 sec
uint32 nanosec
string frame_id

# the first ray in the scan.
#
# in frame frame_id, angles are measured around
# the positive Z axis (counterclockwise, if Z is up)
# with zero angle being forward along the x ax is

float32 angle_min # start angle of the scan [rad]
float32 angle_max # end angle of the scan [rad]
float32 angle_increment # angular distance between measurements [rad]
float32 time_increment # time between measurements [seconds] - if your scanner

# is moving, this will be used in interpolating position
# of 3d points

float32 scan_time # time between scans [seconds]
float32 range_min # minimum range value [m]
float32 range_max # maximum range value [m]
float32[] ranges # range data [m]

# (Note: values < range_min or > range_max should be discarded)
float32[] intensities # intensity data [device-specific units]. Ifyour
# device does not provide intensities, pleaseleave
# the array empty.
```
### <span style="color: green;"> 11. Ejecutar el comando de ROS que permite ver los mensajes publicados en el tópico scan. </span>

```python
user:~$ ros2 topic echo /scan
header:
stamp:
sec: 1369
nanosec: 199000000
frame_id: base_scan
angle_min: 0.0
angle_max: 6.28000020980835
angle_increment: 0.009529590606689453
time_increment: 0.0
scan_time: 0.0
range_min: 0.11999999731779099
range_max: 30.0

ranges:
-  1.0575309991836548
-  1.07778799533844
-  1.103964924812317
-  1.1099289655685425
-  1.1197065114974976
-  1.1077027320861816
-  1.1338632106781006
-  1.14174222946167
-  1.1514971256256104
-  1.152237892150879
-  1.1838010549545288
-  1.1915087699890137
-  1.2091283798217773
-  1.2115062475204468
-  1.219036340713501
-  1.2321397066116333
-  1.2361078262329102
-  1.2719216346740723
-  1.2492176294326782
-  1.289873719215393
-  1.3157765865325928
-  1.3255336284637451
-  1.3427844047546387
-  1.35250985622406
-  1.3917534351348877
-  1.400230884552002
-  1.4222326278686523
- .inf
- .inf
- .inf
- .inf
- .inf
-  1.589845061302185
-  1.5938419103622437
- .inf
- .inf
- .inf
- .inf
- .inf
- .inf
- .inf
- .inf
- .inf
- .inf
- .inf
- .inf
-  2.0834388732910156
-  2.066275119781494
- .inf
- .inf
- .inf
- .inf
- .inf
- .inf
- .inf
-  2.5789315700531006
-  2.578108787536621
- .inf
- .inf
- .inf
- .inf
-  3.096937417984009
- .inf
- .inf
- .inf
-  3.6344234943389893
- .inf
- .inf
- .inf
- .inf
- .inf
-  3.4586660861968994
-  3.453306198120117
-  3.434079170227051
-  3.459045886993408
- .inf
- .inf
-  2.099273920059204
-  2.090024709701538
-  2.050550937652588
-  2.0373117923736572
-  2.0355002880096436
-  2.0081562995910645
-  1.9949225187301636
-  1.9975559711456299
-  1.9955435991287231
-  1.9613300561904907
-  1.9430747032165527
-  1.9342398643493652
-  1.9093196392059326
-  1.9390672445297241
-  1.9889134168624878
-  1.999595046043396
-  1.6781705617904663
-  1.572532057762146
-  1.5767606496810913
-  1.4521607160568237
-  1.4488470554351807
-  1.5832035541534424
-  1.02974534034729
-  1.0472511053085327
-  1.5880757570266724
-  1.5880882740020752
-  1.586401343345642
-  1.5975639820098877
-  1.6018826961517334
-  1.5939562320709229
-  1.1620577573776245
-  1.2016253471374512
-  1.1970022916793823
-  1.083295226097107
-  1.0822309255599976
-  1.1078875064849854
-  1.7393968105316162
-  1.4749510288238525
-  1.6247022151947021
-  1.571722149848938
-  1.135791540145874
-  1.115374207496643
-  1.1111096143722534
-  1.1414421796798706
-  1.3210170269012451
-  1.2757271528244019
-  1.1027803421020508
-  1.090027093887329
-  1.164512276649475
-  1.1519142389297485
-  1.1097389459609985
-  '...'
- 
intensities:
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  0.0
-  '...'
---
```
### <span style="color: green;"> 12. Ejecutar topic echo con las opciones --once y --no-arr, ¿cuáles son los parámetros del barrido láser?, ¿cuántos valores se incluyen en el campo range? </span>

```python

user:~$ ros2 topic echo /scan --once --no-arr
header:
stamp:
sec: 1599
nanosec: 814000000
frame_id: base_scan
angle_min: 0.0
angle_max: 6.28000020980835
angle_increment: 0.009529590606689453
time_increment: 0.0
scan_time: 0.0
range_min: 0.11999999731779099
range_max: 30.0
ranges: '<sequence type: float, length: 660>'
intensities: '<sequence type: float, length: 660>'
---
```